#/bin/bash

INTERVAL=5000;
MAX_OPS=80000;

threads=8;
opcount=10000000
recordcount=10000000
dotransactions=true;
cur_ops=5000;

if [ $# -ne 1 ]; then
    echo "Invalid arguments: Must specify ip address as first and only argument";
    exit 0;
fi

HOST=$1

echo "Setting number of threads to $threads";
sh ../lib/cli.sh set-value $HOST threadcount $threads;
echo "Setting number of operations to $opcount";
sh ../lib/cli.sh set-value $HOST operationcount $opcount;
echo "Setting number of records to $recordcount";
sh ../lib/cli.sh set-value $HOST recordcount $recordcount;
echo "Telling load generator to do transactions";
sh ../lib/cli.sh set-value $HOST dotransactions $dotransactions;

while [ $cur_ops -le $MAX_OPS ]; do
    sh ../lib/cli.sh set-value $HOST target $cur_ops;
    echo $cur_ops;
    sleep 5;
    cur_ops=$(($cur_ops + $INTERVAL)); 
done