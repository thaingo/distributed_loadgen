package com.couchbase.loadgen.rest.ops;

public class SetConfig {

}
